// // FONCTION POUR FLIP LES CARDS
// function flipCard(){

// const card = document.querySelectorAll(".card__inner");

// card__inner.addEventListener("click", function (e) {
//   for(i = 0; i < '.card__inner'; i++) {
//     card = '.card__inner' + i;
//   }
//   card.classList.toggle("is-flipped");
// })
// }
